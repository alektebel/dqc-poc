repo: alektebel/regllm
branch: main
path: DQC/app

## Last sync

date: 2026-09-06T13:30:00Z

### Updated in this project

- Rebuilt the DQC web app UI on the PwC palette (orange #D04A02, red #E0301E, amber #FFB600, ink on white) over the Modernist grid.
- Light, high-legibility redesign of the four layers: proyectos, alta de proyecto, resumen, generar, revisar.
- Review flow reworked to one control at a time with two large actions (Validar / Rechazar); ReAct reasoning stays visible.
- Project creation split into a two-step wizard (datos → revisar y crear).

## Screen map

| Project screen | Built from |
| --- | --- |
| Proyectos | DQC/app/src/app/projects/projects.component.ts, services/project.service.ts |
| Alta de proyecto (wizard) | DQC/app/src/app/projects/projects.component.ts, models/project.model.ts |
| Resumen | DQC/app/src/app/summary/summary.component.ts, app.component.ts |
| Generar | DQC/app/src/app/chat/chat.component.ts, models/dqc.model.ts (PlanItem, TraceStep) |
| Revisar | DQC/app/src/app/editor/editor.component.ts, models/dqc.model.ts (CheckRecord, CheckCasesResponse) |
